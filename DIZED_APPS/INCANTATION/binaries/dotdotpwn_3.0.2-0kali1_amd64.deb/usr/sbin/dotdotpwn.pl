#!/bin/bash

cd /usr/share/dotdotpwn/ && ./dotdotpwn.pl "$@"
