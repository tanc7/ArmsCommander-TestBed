lsmod |grep -i nouveau
