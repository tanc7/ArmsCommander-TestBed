apt-get update && apt-get upgrade && apt-get dist-upgrade -y
