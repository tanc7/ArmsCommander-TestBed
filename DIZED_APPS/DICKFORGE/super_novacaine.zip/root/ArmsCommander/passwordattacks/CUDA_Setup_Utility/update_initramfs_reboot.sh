update-initramfs -u && reboot

