apt-get install -y ocl-icd-libopencl1 nvidia-driver nvidia-cuda-toolkit
